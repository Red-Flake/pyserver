from distutils.core import setup

setup(
    name='pyserver',
    version='0.0.1',
    scripts=['pyserver.py',],
)
